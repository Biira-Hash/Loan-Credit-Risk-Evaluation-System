from utils.db_connection import get_connection
from utils.db_utils import fetch_existing_user
